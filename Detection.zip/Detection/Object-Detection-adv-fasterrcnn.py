!sudo apt-get update
!apt-cache search libgl
!sudo apt-get install libgl1-mesa-glx -y

# Clone GitHub Repo
!git clone https://github.com/facebookresearch/detr.git   

# Basic Libraries
import os
import random
import re
import numpy as np 
import pandas as pd 
from datetime import datetime
import time
import warnings
warnings.filterwarnings("ignore")

# Visualization
from matplotlib import pyplot as plt
from matplotlib import gridspec
from PIL import Image
import cv2

# PyTorch
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.sampler import SequentialSampler, RandomSampler
from torch.utils.data.distributed import DistributedSampler
import torchvision
from torchvision import models
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.models.detection import FasterRCNN
from torchvision.models.detection.rpn import AnchorGenerator

# Albumentations
import albumentations as A
from albumentations.pytorch.transforms import ToTensorV2

# tqdm for progress bars
from tqdm.autonotebook import tqdm
from tqdm.notebook import tqdm as notebook_tqdm

# sklearn
from sklearn import model_selection
from sklearn.model_selection import StratifiedKFold
from skmultilearn.model_selection import iterative_train_test_split
from sklearn.preprocessing import MultiLabelBinarizer

# PyCocoTools
!pip install pycocotools
from pycocotools.coco import COCO

# Grad-CAM
!pip install grad-cam
from pytorch_grad_cam import EigenCAM, AblationCAM
from pytorch_grad_cam.ablation_layer import AblationLayerFasterRCNN
from pytorch_grad_cam.utils.model_targets import FasterRCNNBoxScoreTarget
from pytorch_grad_cam.utils.reshape_transforms import fasterrcnn_reshape_transform
from pytorch_grad_cam.utils.image import show_cam_on_image

# Ensemble Boxes
!pip install ensemble_boxes
from ensemble_boxes import *

# mAP Calculation
!pip install map_boxes
from map_boxes import mean_average_precision_for_boxes

# Glob for file handling
from glob import glob
from engine import evaluate
import gc

import hashlib
import json
import itertools

from TOG.dataset_utils.preprocessing import letterbox_image_padded
from TOG.misc_utils.visualization import visualize_detections
from TOG.models.frcnn import FRCNN
from PIL import Image
from TOG.tog.attacks import *
import os

#DDP
import torch.multiprocessing as mp
from torch.utils.data.distributed import DistributedSampler
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.distributed import init_process_group, destroy_process_group

def ddp_setup(rank, world_size):
    os.environ["MASTER_ADDR"] = "localhost"
    os.environ["MASTER_PORT"] = "50556"
    init_process_group(backend="nccl", rank=rank, world_size=world_size)
    torch.cuda.set_device(rank)

def seed_everything(seed):
    # Set Python random seed
    random.seed(seed)
    
    # Set NumPy random seed
    np.random.seed(seed)
    
    # Set PyTorch random seed for CPU and GPU
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    
    # Set PyTorch deterministic operations for cudnn backend
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

class NoOpAttacker():
    def attack(self, image, label, model):
        return image

class PGDAttacker():
    def __init__(self, num_iter, epsilon, step_size, device):
        self.num_iter = num_iter
        self.epsilon = epsilon / 255
        self.step_size = step_size / 255
        self.device = device

    def attack(self, image_clean, target, model):     
        # 設定上下界
        lower_bound = torch.clamp(image_clean - self.epsilon, min=-1., max=1.)
        upper_bound = torch.clamp(image_clean + self.epsilon, min=-1., max=1.)

        # 隨機初始化
        init_start = torch.empty_like(image_clean).uniform_(-self.epsilon, self.epsilon)
        adv_image = image_clean + init_start
        
        for _ in range(self.num_iter):
            adv_image.requires_grad = True

            # 獲取損失
            loss_dict = model([adv_image], [target])  # 模型期望 batch 格式
            total_loss = sum(loss for loss in loss_dict.values())
            
            # 計算梯度
            grad = torch.autograd.grad(total_loss, adv_image, retain_graph=False, create_graph=False)[0]
            
            # 更新對抗樣本
            adv_image = adv_image + torch.sign(grad) * self.step_size
            adv_image = torch.clamp(adv_image, min=lower_bound, max=upper_bound).detach()

        return adv_image

def read_images():
    # read the images with size 512x512 
    # add the dataset in the data section if it is not added yet
    train_df = pd.read_csv("/home/ttban9527/vinbigdata/train.csv")
    train_df.fillna(0, inplace=True)
    return train_df

def scale_images(train_df):
    # scale the coordinates of the bounding boxes from their initial values to fit the 512x512 images
    # set to the images with no object (class 14), bounding box with coordinates [xmin=0 ymin=0 xmax=1 ymax=1]
    train_df.loc[train_df["class_id"] == 14, ['x_max', 'y_max']] = 1.0
    train_df.loc[train_df["class_id"] == 14, ['x_min', 'y_min']] = 0

    # scale the input image coordinates to fit 512x512 image
    IMG_SIZE = 512
    train_df['xmin'] = (train_df['x_min']/train_df['width'])*IMG_SIZE
    train_df['ymin'] = (train_df['y_min']/train_df['height'])*IMG_SIZE
    train_df['xmax'] = (train_df['x_max']/train_df['width'])*IMG_SIZE
    train_df['ymax'] = (train_df['y_max']/train_df['height'])*IMG_SIZE

    # set to the images with no object (class 14), bounding box with coordinates [xmin=0 ymin=0 xmax=1 ymax=1]
    train_df.loc[train_df["class_id"] == 14, ['xmax', 'ymax']] = 1.0
    train_df.loc[train_df["class_id"] == 14, ['xmin', 'ymin']] = 0
    
    return train_df

def define_folds(train_df):
    unique_images = train_df["image_id"].unique()
    df_split = pd.DataFrame(unique_images, columns = ['unique_images']) 

    # create one column with the number of fold (for the k-fold cross validation)
    df_split["kfold"] = -1
    df_split = df_split.sample(frac=1).reset_index(drop=True)
    y = df_split.unique_images.values
    kf = model_selection.GroupKFold(n_splits=5)
    for f, (t_, v_) in enumerate(kf.split(X=df_split, y=y, groups=df_split.unique_images.values)):
        df_split.loc[v_, "kfold"] = f

    # annotated boxes from same "image id" (image) should be in the same fold [during training each image with its boxes is as one input]
    train_df["kfold"] = -1
    for ind in train_df.index: 
         train_df["kfold"][ind] = df_split.loc[ df_split["unique_images"] ==  train_df["image_id"][ind]]["kfold"]

    train_df.set_index('image_id', inplace=True)
    return train_df

def boxes_fusion(df):
    # apply weighted boxes fusion for ensemling overlapping annotated boxes
    # Default WBF config 
    iou_thr = 0.75
    skip_box_thr = 0.0001
    sigma = 0.1
    results = []
    image_ids = df.index.unique()
   
    for image_id in tqdm(image_ids, total=len(image_ids)):
        # All annotations for the current image.
        data = df[df.index == image_id]
        kfold = data['kfold'].unique()[0]
        data = data.reset_index(drop=True)
        
        # WBF expects the coordinates in 0-1 range.
        max_value = data.iloc[:, 4:].values.max()
        data.loc[:, ["xmin", "ymin", "xmax", "ymax"]] = data.iloc[:, 4:] / max_value
        #print("data",data)
        if data.class_id.unique()[0] !=14:
            annotations = {}
            weights = []
            # Loop through all of the annotations
            for idx, row in data.iterrows():
                rad_id = row["rad_id"]
                if rad_id not in annotations:
                    annotations[rad_id] = {
                        "boxes_list": [],
                        "scores_list": [],
                        "labels_list": [],
                    }
                    # We consider all of the radiologists as equal.
                    weights.append(1.0)
                annotations[rad_id]["boxes_list"].append([row["xmin"], row["ymin"], row["xmax"], row["ymax"]])
                annotations[rad_id]["scores_list"].append(1.0)
                annotations[rad_id]["labels_list"].append(row["class_id"])

            boxes_list = []
            scores_list = []
            labels_list = []

            for annotator in annotations.keys():
                boxes_list.append(annotations[annotator]["boxes_list"])
                scores_list.append(annotations[annotator]["scores_list"])
                labels_list.append(annotations[annotator]["labels_list"])

            # Calculate WBF
            boxes, scores, labels = weighted_boxes_fusion(boxes_list,
                scores_list,
                labels_list,
                weights=weights,
                iou_thr=iou_thr,
                skip_box_thr=skip_box_thr
            )
            for idx, box in enumerate(boxes):
                results.append({
                    "image_id": image_id,
                    "class_id": int(labels[idx]),
                    "rad_id": "wbf",
                    "xmin": box[0]* max_value,
                    "ymin": box[1]* max_value,
                    "xmax": box[2]* max_value,
                    "ymax": box[3]* max_value,
                    "kfold":kfold,
                })
        # if class is nothing then have it once (instead of 3 times in the same image)
        if data.class_id.unique()[0] ==14:
            for idx, box in enumerate([0]):
                results.append({
                    "image_id": image_id,
                    "class_id": data.class_id[0],
                    "rad_id": "wbf",
                    "xmin": 0,
                    "ymin": 0,
                    "xmax": 1,
                    "ymax": 1,
                    "kfold":kfold,
                })
            
    results = pd.DataFrame(results)
    return results

def pascal_to_coco(train_df):
    # Good exlanation of coco, pascal etc 
    # https://albumentations.ai/docs/getting_started/bounding_boxes_augmentation/
    
    train_df['coco_x'] = train_df['xmin']  # Top-left x-coordinate
    train_df['coco_y'] = train_df['ymin']  # Top-left y-coordinate
    train_df['coco_w'] = train_df['xmax'] - train_df['xmin']  # Width
    train_df['coco_h'] = train_df['ymax'] - train_df['ymin']  # Height

    train_df.loc[train_df['class_id'] == 14, 'coco_x'] = 0
    train_df.loc[train_df['class_id'] == 14, 'coco_y'] = 0
    train_df.loc[train_df['class_id'] == 14, 'coco_w'] = 1
    train_df.loc[train_df['class_id'] == 14, 'coco_h'] = 1
    
    return train_df

def preprocessing():
    train_df = read_images()
    train_df = scale_images(train_df)
    train_df = define_folds(train_df)
    train_df = boxes_fusion(train_df)
    train_df = pascal_to_coco(train_df)
    return train_df

def coco_format(df):
    coco_output = {
        "images": [],
        "categories": [],
        "annotations": []
    }

    # 獲取唯一的 `class_id` 作為分類
    unique_classes = df['class_id'].unique()
    for class_id in unique_classes:
        coco_output["categories"].append({
            "id": int(class_id),  # 類別 ID
            "name": f"class_{class_id}"  # 自動命名為 class_x 格式
        })

    annotation_id = 0

    # 遍歷唯一的 image_id
    for image_id, img_name in enumerate(df.image_id.unique()):
        # 選取當前 image_id 的資料
        image_df = df[df.image_id == img_name]

        # 提取圖片寬高，假設所有框的圖片維度一致
        unique = image_df.iloc[0]
        image_dict = {
            "file_name": f"{img_name}",  # 假設圖片文件名為 `image_id.jpg`
            "height": 512,  # 使用 ymax 作為圖片高度
            "width": 512,   # 使用 xmax 作為圖片寬度
            "id": image_id
        }
        coco_output['images'].append(image_dict)

        # 添加 annotations
        for _, row in image_df.iterrows():

            xmin = int(row['xmin'])
            ymin = int(row['ymin'])
            xmax = int(row['xmax'])
            ymax = int(row['ymax'])
            area = (xmax - xmin) * (ymax - ymin)

            # 定義 segmentation，假設是矩形框
            poly = [
                (xmin, ymin), (xmax, ymin),
                (xmax, ymax), (xmin, ymax)
            ]
            poly = list(itertools.chain.from_iterable(poly))

            # 構建 annotation
            mask_dict = {
                "id": annotation_id,
                "image_id": image_id,
                "category_id": int(row['class_id']),
                "bbox": [xmin, ymin, (xmax - xmin), (ymax - ymin)],
                "area": area,
                "iscrowd": 0,
                "segmentation": [poly]
            }
            coco_output["annotations"].append(mask_dict)
            annotation_id += 1

    return coco_output

def get_train_transforms():
    return A.Compose([
        A.ToGray(p=0.01),
        #A.HorizontalFlip(p=0.5),
        #A.RandomBrightnessContrast(p=0.2),  
        ToTensorV2()
    ], 
    bbox_params=A.BboxParams(format='pascal_voc', min_area=0, min_visibility=0, label_fields=['labels']))

def get_valid_transforms():
    return A.Compose([
        ToTensorV2()
    ],
    bbox_params=A.BboxParams(format='pascal_voc', min_area=0, min_visibility=0, label_fields=['labels']))

class VinDataset(Dataset):
    def __init__(self, data, transforms=None):
        """
        Args:
            data (dict): 包含圖像、標註等資料的字典
            image_dir (str): 圖像文件的路徑
            transforms (callable, optional): 數據增強操作（包括圖像和標註）
        """
        self.image_dir = "/home/ttban9527/vinbigdata/train"
        self.images = data['images']
        self.annotations = data['annotations']
        self.categories = data['categories']
        self.transforms = transforms

        # 使用圖像的 ID 作為索引
        self.image_ids = [int(image['id']) for image in self.images]

    def __len__(self):
        return len(self.image_ids)

    def __getitem__(self, index):
        # 獲取當前圖像的 ID 和元數據
        image_id = self.image_ids[index]
        img_metadata = next(item for item in self.images if item['id'] == image_id)
        file_name = img_metadata['file_name']
        img_path = f"{self.image_dir}/{file_name}.png"

        # 加載圖像並轉換為 RGB
        image = cv2.imread(img_path, cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError(f"Image not found: {img_path}")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32)

        # 獲取當前圖像的標註數據
        anns = [ann for ann in self.annotations if ann['image_id'] == image_id]

        # 提取邊界框和類別標籤
        boxes = []
        labels = []
        iscrowd = []
        for ann in anns:
            x, y, w, h = ann['bbox']  # COCO 格式 [x_min, y_min, width, height]
            x_min, y_min, x_max, y_max = x, y, x + w, y + h

            # 檢查框是否有效
            if x_max <= x_min or y_max <= y_min:
                continue  # 跳過該框

            boxes.append([x_min, y_min, x_max, y_max])
            labels.append(ann['category_id'])
            iscrowd.append(ann.get('iscrowd', 0))  # 默認設為 0

        # 將 boxes 和 labels 轉換為 NumPy 或空數組
        boxes = np.array(boxes, dtype=np.float32) if boxes else np.zeros((0, 4), dtype=torch.float32)
        labels = np.array(labels, dtype=np.int64) if labels else np.zeros((0,), dtype=torch.float32)
        iscrowd = np.array(iscrowd, dtype=np.int64) if iscrowd else np.zeros((0,), dtype=torch.int64)

        # 如果有數據增強，應用於圖像和標註
        if self.transforms:
            sample = {
                'image': image,
                'bboxes': boxes,
                'labels': labels
            }
            sample = self.transforms(**sample)
            image = sample['image']
            boxes = np.array(sample['bboxes'], dtype=np.float32)
            labels = np.array(sample['labels'], dtype=np.int64)

        # 構造目標（target）字典
        target = {
            'boxes': torch.as_tensor(boxes, dtype=torch.float32),
            'labels': torch.as_tensor(labels, dtype=torch.int64),
            'image_id': image_id,
            'area': torch.as_tensor(
                (boxes[:, 2] - boxes[:, 0]) * (boxes[:, 3] - boxes[:, 1]), dtype=torch.float32
            ),
            'iscrowd': torch.as_tensor(iscrowd, dtype=torch.int64),
        }

        # 正規化圖像到 [0, 1]
        image = image / 255.0

        return image, target

def fasterrcnn(num_classes):
    model = models.detection.fasterrcnn_resnet50_fpn(weights='COCO_V1') 
    in_features = model.roi_heads.box_predictor.cls_score.in_features
    model.roi_heads.box_predictor = None
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)
    
    return model

def data_split(train_df, train_ratio, valid_ratio, test_ratio):
    assert train_ratio + valid_ratio + test_ratio == 1, "分配比例之和必須等於 1"
    
    binarizer = MultiLabelBinarizer()
    disease_id = []

    # 構建每個圖像對應的疾病類別列表
    for image_id in train_df.image_id.unique():
        diseases = []
        temp = train_df[train_df["image_id"] == image_id]
        diseases.extend(list(temp["class_id"]))
        disease_id.append(diseases)

    # 將疾病類別進行 one-hot 編碼
    one_hot = binarizer.fit_transform(disease_id)
    
    # 第一步：劃分為訓練集和剩餘部分
    train_size = train_ratio
    remaining_size = 1 - train_size
    
    train_ID, train_label, remaining_ID, remaining_label = iterative_train_test_split(
        np.expand_dims(train_df["image_id"].unique(), axis=1),
        one_hot,
        test_size=remaining_size
    )
    
    # 第二步：劃分剩餘部分為驗證集和測試集
    valid_size = valid_ratio / (valid_ratio + test_ratio)  # 調整比例
    val_ID, val_label, test_ID, test_label = iterative_train_test_split(
        remaining_ID,
        remaining_label,
        test_size=(1 - valid_size)
    )
    
    # 構建訓練、驗證和測試數據集
    training = train_df[train_df["image_id"].isin(train_ID.ravel())]
    validation = train_df[train_df["image_id"].isin(val_ID.ravel())]
    testing = train_df[train_df["image_id"].isin(test_ID.ravel())]
    
    return training, validation, testing

def collate_fn(batch):
    return tuple(zip(*batch))

class Trainer:
    def __init__(
        self,
        model: torch.nn.Module,
        train_data: DataLoader,
        valid_data: DataLoader,
        optimizer: torch.optim.Optimizer,
        scheduler: torch.optim.lr_scheduler,
        gpu_id: int,
        best_loss: float,
        lr: float,
        batch_size: int,
        
        
    ) -> None:
        self.gpu_id = gpu_id
        self.model = model.to(gpu_id)
        self.train_data = train_data
        self.valid_data = valid_data
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.best_loss = best_loss
        self.lr = lr
        self.batch_size = batch_size
        self.model = DDP(model, device_ids=[gpu_id])

    def _run_epoch(self, epoch):
        self.model.train()

        train_loss = []
        train_loss_dict = []

        tk0 = tqdm(self.train_data, total=len(self.train_data))
        attacker = PGDAttacker(5, 10, 2, self.gpu_id)

        for step, (images, targets) in enumerate(tk0):
            image = images[0].to(self.gpu_id)
            target = {k: (v.to(self.gpu_id) if isinstance(v, torch.Tensor) else v) for k, v in targets[0].items()}
            
            adv_image = attacker.attack(image, target, self.model)
            
            if step % 2 == 0:
                adv_image = attacker.attack(image, target, self.model)
            else:
                adv_image = image
            
            loss = self.model(adv_image.unsqueeze(0), [target])
            total_loss = sum(l for l in loss.values())

            loss_value = total_loss.item()
            loss_dict = {k: v.item() for k, v in loss.items()}
            
            train_loss.append(loss_value)
            train_loss_dict.append(loss_dict)
            
            self.optimizer.zero_grad()
            total_loss.backward()
            self.optimizer.step()
            
        self.scheduler.step()
        
        train_loss = np.mean(train_loss)
        train_loss_dict = pd.DataFrame(train_loss_dict)
        train_loss_classifier = train_loss_dict['loss_classifier'].mean()
        train_loss_box_reg = train_loss_dict['loss_box_reg'].mean()
        train_loss_rpn_box_reg = train_loss_dict['loss_rpn_box_reg'].mean()
        train_loss_objectness = train_loss_dict['loss_objectness'].mean()

        return train_loss, train_loss_classifier, train_loss_box_reg, train_loss_rpn_box_reg, train_loss_objectness

    def _run_vaild(self):
        self.model.train()
    
        for m in self.model.modules():
            if isinstance(m, torchvision.ops.Conv2dNormActivation):
                m.eval()
            if isinstance(m, torchvision.ops.FrozenBatchNorm2d):
                m.eval()
            if isinstance(m, torch.nn.BatchNorm2d):
                m.eval()
        
        val_loss = []
        val_loss_dict = []
        
        tk0 = tqdm(self.valid_data, total=len(self.valid_data))
        attacker = PGDAttacker(5, 10, 2, self.gpu_id)

        for step, (images, targets) in enumerate(tk0):
            image = images[0].to(self.gpu_id)
            target = {k: (v.to(self.gpu_id) if isinstance(v, torch.Tensor) else v) for k, v in targets[0].items()}
            
            adv_image = attacker.attack(image, target, self.model)
            
            loss = self.model(adv_image.unsqueeze(0), [target])
            total_loss = sum(l for l in loss.values())

            loss_value = total_loss.item()
            loss_dict = {k: v.item() for k, v in loss.items()}
            
            val_loss.append(loss_value)
            val_loss_dict.append(loss_dict)
        
        val_loss = np.mean(val_loss)
        val_loss_dict = pd.DataFrame(val_loss_dict)
        
        val_loss_classifier = val_loss_dict['loss_classifier'].mean()
        val_loss_box_reg = val_loss_dict['loss_box_reg'].mean()
        val_loss_rpn_box_reg = val_loss_dict['loss_rpn_box_reg'].mean()
        val_loss_objectness = val_loss_dict['loss_objectness'].mean()
        
        return val_loss, val_loss_classifier, val_loss_box_reg, val_loss_rpn_box_reg, val_loss_objectness
    
    def _save_checkpoint(self, epoch):
        ckp = self.model.module.state_dict()
        PATH = "adv_fasterrcnncheckpoint.pth"
        torch.save(ckp, PATH)
        print(f"Epoch {epoch+1} | Training checkpoint saved at {PATH}")

    def train(self, max_epochs: int):
        history = {
            "train": {
                "loss": [],
                "loss_classifier": [],
                "loss_box_reg": [],
                "loss_rpn_box_reg": [],
                "loss_objectness": []
            },
            "val": {
                "loss": [],
                "loss_classifier": [],
                "loss_box_reg": [],
                "loss_rpn_box_reg": [],
                "loss_objectness": []
            },
        }
        for epoch in range(max_epochs):
            train_loss, train_loss_classifier, train_loss_box_reg, train_loss_rpn_box_reg, train_loss_objectness = self._run_epoch(epoch)
            val_loss, val_loss_classifier, val_loss_box_reg, val_loss_rpn_box_reg, val_loss_objectness = self._run_vaild()
            
            
            history["train"]["loss"].append(train_loss)
            history["train"]["loss_classifier"].append(train_loss_classifier)
            history["train"]["loss_box_reg"].append(train_loss_box_reg)
            history["train"]["loss_rpn_box_reg"].append(train_loss_rpn_box_reg)
            history["train"]["loss_objectness"].append(train_loss_objectness)
        
            history["val"]["loss"].append(val_loss)
            history["val"]["loss_classifier"].append(val_loss_classifier)
            history["val"]["loss_box_reg"].append(val_loss_box_reg)
            history["val"]["loss_rpn_box_reg"].append(val_loss_rpn_box_reg)
            history["val"]["loss_objectness"].append(val_loss_objectness)


            print(f'|GPU {self.gpu_id}| |EPOCH {epoch+1}| lr: {self.optimizer.state_dict()["param_groups"][0]["lr"]:.6f}')
            print("*****Training*****")
            print(f'Loss: {train_loss:.4f} | Classifier Loss: {train_loss_classifier:.4f} | Box Reg Loss: {train_loss_box_reg:.4f} | RPN Box Reg Loss: {train_loss_rpn_box_reg:.4f} | Objectness Loss: {train_loss_objectness:.4f}')
            #train_evaluator = evaluate(self.model, self.train_data, device = self.gpu_id)
            print("*****Validation*****")
            print(f'Loss: {val_loss:.4f} | Classifier Loss: {val_loss_classifier:.4f} | Box Reg Loss: {val_loss_box_reg:.4f} | RPN Box Reg Loss: {val_loss_rpn_box_reg:.4f} | Objectness Loss: {val_loss_objectness:.4f}')
            valid_evaluator = evaluate(self.model, self.valid_data, device = self.gpu_id)
        
            if self.gpu_id == 0 and valid_evaluator.coco_eval["bbox"].stats[1] > self.best_loss:
                self.best_loss = valid_evaluator.coco_eval["bbox"].stats[1]
                self._save_checkpoint(epoch)

def prepare_dataloader(dataset: Dataset, batch_size: int, collate_fn):
    return DataLoader(
        dataset,
        batch_size=batch_size,
        pin_memory=True,
        shuffle=False,
        num_workers=4,
        collate_fn=collate_fn,
        sampler=DistributedSampler(dataset)
    )

def load_model():
    ## Loading a model
    num_classes = 15
    model = fasterrcnn(num_classes=num_classes)
    best_ckpt = torch.load("fasterrcnncheckpoint.pth", map_location=torch.device('cpu'))
    model.load_state_dict(best_ckpt)
    return model

def main(rank: int, world_size: int, root: str, num_classes: int, batch_size: int,  total_epochs: int,
         weight_decay: float, lr: float, momentum: float, gamma: float, seed: int):

    seed_everything(seed)
    ddp_setup(rank, world_size)

    train_df = preprocessing()

    gc.collect()
    torch.cuda.empty_cache()
    
    df_train, df_valid, df_test = data_split(train_df, 0.7, 0.1, 0.2)
    
    df_train = coco_format(df_train)
    df_valid = coco_format(df_valid)
    
    train_dataset = VinDataset(data=df_train, transforms=get_train_transforms())
    valid_dataset = VinDataset(data=df_valid, transforms=get_valid_transforms())

    train_data = prepare_dataloader(train_dataset, batch_size, collate_fn)
    valid_data = prepare_dataloader(valid_dataset, batch_size, collate_fn)
    
    model = load_model()
    milestones = [11, 15]

    parameters = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.SGD(parameters, lr = lr, momentum = momentum, weight_decay = weight_decay)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones = milestones, gamma = gamma)
    
    best_loss = 0
    trainer = Trainer(model, train_data, valid_data, optimizer, scheduler, rank,
                      best_loss, lr, batch_size)
    trainer.train(total_epochs)

    destroy_process_group()

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='simple distributed training job')
    parser.add_argument('--root', default="/home/ttban9527/vinbigdata/train", type=str)
    parser.add_argument('--num_classes', default=15, type=int)
    parser.add_argument('--batch_size', default=1, type=int)
    parser.add_argument('--total_epochs', default=20, type=int)
    parser.add_argument('--weight_decay', default=5e-4, type=float)
    parser.add_argument('--lr', default=5e-3, type=float)
    parser.add_argument('--momentum', default=0.85, type=float)
    parser.add_argument('--gamma', default=0.1, type=float)
    parser.add_argument('--seed', default=42, type=int)
    args = parser.parse_args()
    
    world_size = torch.cuda.device_count()
    mp.spawn(main, args=(world_size,
                         args.root,
                         args.num_classes,
                         args.batch_size,
                         args.total_epochs,
                         args.weight_decay,
                         args.lr,
                         args.momentum,
                         args.gamma,
                         args.seed), nprocs=world_size)
